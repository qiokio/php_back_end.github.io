<?php

$host='http://qiokio.github.io['HTTP_HOST'].'/';
//本站域名

$typearr=array("png","jpg","txt","text","html","js","mp4","vdat");
//自定义文件格式类型，要关联type.php文件


define("HOST",$host);

define("TYPE",$typearr);

?>